# Similarity Search Project

## Setup Instructions

1. **Install Dependencies**
   ```bash
   pip install -r requirements.txt
   ```

2. **Install sqlite-vec Extension**
   Follow instructions at: https://github.com/asg017/sqlite-vec

3. **Migrate Database**
   ```bash
   python manage.py migrate
   ```

4. **Create Superuser**
   ```bash
   python manage.py createsuperuser
   ```

5. **Load Sample Data**
   ```bash
   python scripts/data_loader.py
   ```

6. **Run the Server**
   ```bash
   python manage.py runserver
   ```

7. **Access the Application**
   - Signup: http://localhost:8000/signup/
   - Home: http://localhost:8000/
